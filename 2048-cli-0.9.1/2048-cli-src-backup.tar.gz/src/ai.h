#ifndef AI_H
#define AI_H

#include "engine.h"

int ai_move(struct gamestate *g);

#endif
